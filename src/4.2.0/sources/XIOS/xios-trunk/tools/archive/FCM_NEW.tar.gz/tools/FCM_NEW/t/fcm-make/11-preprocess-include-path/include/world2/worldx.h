character(*), parameter :: world1 = 'Moon'
