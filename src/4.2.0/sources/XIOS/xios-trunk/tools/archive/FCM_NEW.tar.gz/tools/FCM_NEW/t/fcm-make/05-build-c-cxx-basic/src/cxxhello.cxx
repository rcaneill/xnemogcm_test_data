#include <iostream>

int main() {
    std::cout << "Hello C++\n";
    return 0;
}
